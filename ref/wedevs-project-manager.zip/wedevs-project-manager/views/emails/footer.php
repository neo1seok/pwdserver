

		<div style="height: 71px; background: #454545;">
			<center style="padding-top: 25px;"><a style="text-decoration: none; font-family: arial; font-size: 20px; color: #fff;" href="<?php echo home_url(); ?>"><?php echo get_bloginfo('name'); ?></a></center>
		</div>
		</td>
		</tr>
		</table>
	</div>
</div>
