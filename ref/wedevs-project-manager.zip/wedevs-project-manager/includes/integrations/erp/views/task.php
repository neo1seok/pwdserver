<div class="cpm-emp-btn-wrap" style="padding: 20px 10px;">
    <a href="#" id="cpm-emp-assign-task" class="button button-primary"><?php _e( 'Assign New Task', 'cpm' ); ?></a><br>
</div>

<?php erp_get_js_template( CPMERP_VIEWS . '/task-form.php', 'erp-custom-address' ); ?>
